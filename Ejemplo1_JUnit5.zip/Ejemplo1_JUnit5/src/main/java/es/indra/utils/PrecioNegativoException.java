package es.indra.utils;

public class PrecioNegativoException extends RuntimeException{
	
	public PrecioNegativoException(String mensaje) {
		super(mensaje);
	}

}
