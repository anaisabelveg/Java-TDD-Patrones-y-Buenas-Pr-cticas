package es.indra.models;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ProductoTest {
	
	Producto producto;
	
	// Los metodos anotados como @BeforeAll y @AfterAll siempre han de ser estaticos
	// y ademas no pueden estar en clases anidadas
	@BeforeAll
	static void inicioClasePrueba() {
		// Iniciar el log para almacenar el resultado de las pruebas
		System.out.println("Empezamos a probar la clase ProductoTest");
	}
	
	@AfterAll
	static void finClasePrueba() {
		System.out.println("Hemos terminado de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioPrueba() {
		producto = new Producto(1, "Impresora", 89.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finPrueba() {
		System.out.println("Prueba terminada");
	}
	
	@Nested
	@DisplayName("Probando los test de la clase Producto")
	class ProductoPruebas{
		
		@Test
		@DisplayName("Probando la descripcion del producto")
		@Tag("producto")
		void testDescripcion() {
			// Patron AAA
			// Arrange
			//Producto producto = new Producto(1, "Impresora", 89.95);
			String descripcionEsperada = "Impresora";
			// Act
			String descripcionReal = producto.getDescripcion();
			// Assert
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}
		
		@Test
		@DisplayName("Probando el precio del producto")
		@Tag("producto")
		void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 89.95);
			//Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}
		
		// Testear la igualdad de productos
		@Test
		void testIgualdadProductos() {
			//Producto producto = new Producto(1, "Impresora", 89.95);
			Producto producto2 = new Producto(1, "Impresora", 89.95);
			Assertions.assertEquals(producto, producto2);
		}
		
		@Test
		void testPrecioNegativoException() {
			Exception exception = Assertions.assertThrows(Exception.class, () -> {
				producto.setPrecio(-123);
			});
			
			String msgReal = exception.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			assertEquals(msgEsperado, msgReal);
		}
		
	}
	
	@Nested
	@DisplayName("Probando los test de la clase Proveedor")
	//@Disabled
	@Tag("producto")
	@Tag("proveedor")
	class ProveedorPruebas{
		
		@Test
		void testRelacionProductoProveedor() {
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			
			proveedor.addProducto(producto);
			proveedor.addProducto(new Producto(2, "Scanner", 250));
			
			Assertions.assertAll(
					// La lista de productos no es nula
					() -> Assertions.assertNotNull(proveedor.getProductos()),
					// Ahora tenemos 2 productos en esa lista
					() -> Assertions.assertEquals(2, proveedor.getProductos().size(), 
							"En la lista del proveedor deberia haber 2 productos"),
					// Si el proveedor tiene un producto Impresora
					() -> Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
							.filter(prod -> "Impresora".equals(prod.getDescripcion()))
							.findFirst()
							.get()
							.getDescripcion())
			);
		}
	}
	
	@Nested
	@DisplayName("Habilitar o deshabilitar pruebas segun SO, JRE")
	class SO_JRE{
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("Tu SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("Tu SO es Mac o Linux");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNoSOWindows() {
			System.out.println("Deshabilitado si tu SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testSoloJava8() {
			System.out.println("Probando test en Java 8");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_25)
		void testSoloJava25() {
			System.out.println("Probando test en Java 25");
		}
	}
	
	@Nested
	@DisplayName("Pruebas de System Properties")
	class SystemProperties{
		@Test
		void verSystemProperties() {
			Properties properties = System.getProperties();
			properties.forEach((k,v) -> System.out.println(k + ": " + v));
		}
		
		// java.version: 1.8.0_482
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_482")
		void testJavaVersion() {
			System.out.println("Tu version de java es 1.8.0_482");
		}
		
		// Tambien funciona con expresiones regulares
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
		void testJavaVersion2() {
			System.out.println("Tu version de java es 1.8.*");
		}
		
		@Test
		@DisabledIfSystemProperty(named = "java.version", matches = "22.*")
		void testJavaVersion22() {
			System.out.println("Tu version de java no es 22.*");
		}
	}
	
	// Que es Assumptions?
	// Habilitar o dehabilitar un test o parte del test en funcion de 
	// una condicion de forma programatica
	@Test
	@DisplayName("Probando el precio del producto con assumptions")
	void testPrecioAssumptions() {
		
		boolean condicion = true;
		
		Assumptions.assumingThat(condicion, () -> {
			Assertions.assertFalse(producto.getPrecio() <= 0);
			Assertions.assertEquals(89.95, producto.getPrecio());
			Assertions.assertEquals("bbbbb", producto.getDescripcion());
		});		
	}
	
	@RepeatedTest(value=3, name="Repeticion {currentRepetition} de {totalRepetitions}")
	void testRepetido(RepetitionInfo infoRep) {
		System.out.println("Estamos en la repeticion numero: " + infoRep.getCurrentRepetition());
		double numero = Math.random();
		System.out.println(numero);
		Assertions.assertNotNull(numero);
		Assertions.assertTrue(numero > 0);
	}
	
	// Test parametrizados: se trata de pasar varios datos como parametros
	// y asi realizar la prueba con cada uno de ellos
	@ParameterizedTest(name="parametro {index} con valor {0}")
	@ValueSource(doubles = {129.85, -30, 275, 0})
	void testPrecio(double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name="parametro {index} con valor {1}")
	@CsvSource({"0,129.85", "1,-30", "2,275", "3,0"})
	void testPrecioCsvSource(String idx, String precio) {
		producto.setPrecio(Double.parseDouble(precio));
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name="parametro {index} con valor {0}")
	@CsvFileSource(resources = "/datos.csv")
	void testPrecioCsvSource(String precio) {
		producto.setPrecio(Double.parseDouble(precio));
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	@ParameterizedTest(name="parametro {index} con valor {0}")
	@MethodSource("queryPrecios")
	void testPrecioMethodSource(Double precio) {
		producto.setPrecio(precio);
		Assertions.assertTrue(producto.getPrecio() > 0);
	}
	
	static List<Double> queryPrecios(){
		// Simulamos que lanzamos una query a la BBDD para traer la lista de precios
		return Arrays.asList(129.85, -30.0, 275.0, 0.0);
	}
}









