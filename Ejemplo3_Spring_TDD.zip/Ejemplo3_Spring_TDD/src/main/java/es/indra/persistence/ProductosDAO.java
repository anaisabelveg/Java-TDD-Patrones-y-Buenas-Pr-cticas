package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.entities.Producto;

// En Spring Boot cuando heredas de xxxRepository, lo reconoce como un bean de Spring
public interface ProductosDAO extends JpaRepository<Producto, Long>{
	
	// Tambien se pueden crear metodos utilizando keywords
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	public List<Producto> findByDescripcion(String descripcion);
	
	public List<Producto> findByPrecioBetween(double min, double max);

}
