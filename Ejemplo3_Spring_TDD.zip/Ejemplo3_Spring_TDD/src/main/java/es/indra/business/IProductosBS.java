package es.indra.business;

import java.util.List;

import es.indra.entities.Producto;

public interface IProductosBS {
	
	List<Producto> consultarTodos();
	
	Producto buscarProducto(Long id);
	
	Producto crearNuevo(String descripcion, double precio);
	
	Producto modificarPrecio(Long id, double nuevoPrecio);
	
	boolean eliminarProducto(Long id);

}
