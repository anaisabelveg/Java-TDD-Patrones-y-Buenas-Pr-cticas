package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElseThrow( () -> new RuntimeException("Producto inexistente"));
	}

	@Override
	public Producto crearNuevo(String descripcion, double precio) {
		Producto producto = new Producto(descripcion, precio);
		return dao.save(producto);
	}

	@Override
	public Producto modificarPrecio(Long id, double nuevoPrecio) {
		Producto producto = buscarProducto(id);
		producto.setPrecio(nuevoPrecio);
		return dao.save(producto);
	}

	@Override
	public boolean eliminarProducto(Long id) {
		boolean eliminado = false;
		try {
			dao.deleteById(id);
			eliminado = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return eliminado;
	}

}
