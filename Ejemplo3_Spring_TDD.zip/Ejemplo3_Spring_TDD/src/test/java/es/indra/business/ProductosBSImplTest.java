package es.indra.business;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;
import es.indra.utils.Datos;

/*
 * Probamos con JUnit y Mockito sin levantar el contexto de Spring
 * */

@ExtendWith(MockitoExtension.class)
public class ProductosBSImplTest {
	
	@Mock
	private ProductosDAO dao;
	
	@InjectMocks
	private ProductosBSImpl bs;
	
	@Test
	void testBuscarProducto() {
		//Producto producto = new Producto("Teclado", 50.89);
		Mockito.when(dao.findById(2L)).thenReturn(Optional.of(Datos.PRODUCTO));
		
		Producto productoEncontrado = bs.buscarProducto(2L);
		
		Assertions.assertNotNull(productoEncontrado);
		Mockito.verify(dao).findById(Mockito.anyLong());
	}
	
	@Test
	void testBuscarProductoNoExiste() {
		Exception ex = Assertions.assertThrows(RuntimeException.class, () -> {
			bs.buscarProducto(567L);
		});
		
		Assertions.assertEquals(RuntimeException.class, ex.getClass());
		Assertions.assertEquals("Producto inexistente", ex.getMessage());
	}
	
	@Test
	void testConsultarTodos() {
		Mockito.when(dao.findAll()).thenReturn(Datos.lista);
		
		List<Producto> lista = bs.consultarTodos();
		
		Mockito.verify(dao).findAll();
		Assertions.assertTrue(lista.size() == 6);
		Assertions.assertEquals("Monitor", lista.stream()
				.filter(prod -> "Monitor".equals(prod.getDescripcion()))
				.findAny()
				.get()
				.getDescripcion());
	}
	
	@Test
	void testCrearNuevo() {
		Mockito.when(dao.save(Mockito.any(Producto.class))).thenReturn(Datos.NUEVO_PRODUCTO);
		
		Producto producto = bs.crearNuevo("Prueba", 123.45);
		
		Assertions.assertEquals(7L, producto.getID());
		Assertions.assertNotNull(producto);
		Assertions.assertEquals("Prueba", producto.getDescripcion());
		
		Mockito.verify(dao).save(Mockito.any(Producto.class));
	}
	
	@Test
	void testModificarPrecio() {
		Mockito.when(dao.findById(Mockito.anyLong()))
			.thenReturn(Optional.of(Datos.PRODUCTO));
		
		Mockito.when(dao.save(Mockito.any(Producto.class))).thenReturn(Datos.PRODUCTO);
		
		Producto producto = bs.modificarPrecio(2L, 8765.60);
		
		Mockito.verify(dao).findById(Mockito.anyLong());
		Mockito.verify(dao).save(Mockito.any(Producto.class));
	}
	
	@Test
	void testEliminarProducto() {
		// como dao.deleteById(id) es void no necesito preparacion previa
		
		boolean eliminado = bs.eliminarProducto(Mockito.anyLong());
		 
		Assertions.assertTrue(eliminado);
		Mockito.verify(dao).deleteById(Mockito.anyLong());
		
	}

}













