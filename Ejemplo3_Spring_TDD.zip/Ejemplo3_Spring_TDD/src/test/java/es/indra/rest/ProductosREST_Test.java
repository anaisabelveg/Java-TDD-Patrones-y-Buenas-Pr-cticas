package es.indra.rest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductosREST_Test {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	void buscar() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/api/productos/buscar/3"))
			.andExpect(MockMvcResultMatchers.status().isOk())
			.andExpect(MockMvcResultMatchers.jsonPath("$.descripcion").value("Raton"));
	}
	
	@Test
	void listar() throws Exception {
		MvcResult resultado = mockMvc.perform(MockMvcRequestBuilders.get("/api/productos/listar"))
			//.andDo(MockMvcResultHandlers.print())  // pinta toda la respuesta
			.andExpect(MockMvcResultMatchers.status().isOk())
			.andReturn();
		
		System.out.println(resultado.getResponse().getContentAsString());
	}
	
	@Test
	void crear() throws Exception{
		MvcResult resultado = mockMvc.perform(MockMvcRequestBuilders.post("/api/productos/crear/descripcion/Prueba/precio/123.45"))
			.andExpect(MockMvcResultMatchers.status().isOk())
			.andExpect(MockMvcResultMatchers.jsonPath("$.descripcion").value("Prueba"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.precio").value("123.45"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.id").value("7"))
			.andReturn();
		
		System.out.println(resultado.getResponse().getContentAsString());
	}
	
	@Test
	void modificar() throws Exception{	
		mockMvc.perform(MockMvcRequestBuilders.put("/api/productos/modificar/2/precio/99.99"))
			.andExpect(MockMvcResultMatchers.status().isOk())
			.andExpect(MockMvcResultMatchers.jsonPath("$.descripcion").value("Teclado"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.precio").value("99.99"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.id").value("2"));
	}
	
	@Test
	void eliminar() throws Exception{
		mockMvc.perform(MockMvcRequestBuilders.delete("/api/productos/eliminar/6"))
		.andExpect(MockMvcResultMatchers.status().isOk())
			.andDo(MockMvcResultHandlers.print())
			.andExpect(MockMvcResultMatchers.content().string("true"));
	}

}














