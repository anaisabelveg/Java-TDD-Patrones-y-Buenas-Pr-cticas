package es.indra.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import es.indra.models.Pelicula;
import es.indra.persistence.IPeliculasDAO;
import es.indra.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSImplTest {
	
	@Mock
	IPeliculasDAO dao;
	
	@InjectMocks
	// No puedo inyectar dependencias en una interface, es necesario utilizar la clase
	//IPeliculasBS bs;
	PeliculasBSImpl bs;
	
	@BeforeEach
	void inicioPrueba() {
		// Crear un mock (objeto ficticio del dao)
		// No se puede crear un mock de cualquier metodo, solo publicos o default,
		// nunca de un metodo provado o estatico y tampoco final
		//dao = Mockito.mock(IPeliculasDAO.class);
		//bs = new PeliculasBSImpl(dao);
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con la anotacion @ExtendWith
		//MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFindPeliculaByNombre() {
		// Cargar los datos al llamar al findAll() del dao
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}
	
	@Test
	void testCrearPelicula() {
		// Patron AAA  ->  JUnit
		// Patron Given, When, Then  -> Mockito
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		//Mockito.when(dao.crear(peliculaNueva)).thenReturn(Datos.PELICULA);
		// Ahora mockeamos la pelicula a crear
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		// Con verify comprobamos que se invoco al metodo crear del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class));
	}
}



