package es.indra.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatcher;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import es.indra.models.Pelicula;
import es.indra.persistence.ActoresDAOImpl;
import es.indra.persistence.IPeliculasDAO;
import es.indra.persistence.PeliculasDAOImpl;
import es.indra.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSImplTest {
	
	@Mock
	IPeliculasDAO dao;
	
	@Mock
	// Mockito.doCallRealMethod() necesito el mock de la clase y no de la interface
	//IActoresDAO actoresDAO;
	ActoresDAOImpl actoresDAO;
	
	@InjectMocks
	// No puedo inyectar dependencias en una interface, es necesario utilizar la clase
	//IPeliculasBS bs;
	PeliculasBSImpl bs;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	@BeforeEach
	void inicioPrueba() {
		// Crear un mock (objeto ficticio del dao)
		// No se puede crear un mock de cualquier metodo, solo publicos o default,
		// nunca de un metodo provado o estatico y tampoco final
		//dao = Mockito.mock(IPeliculasDAO.class);
		//bs = new PeliculasBSImpl(dao);
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con la anotacion @ExtendWith
		//MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFindPeliculaByNombre() {
		// Cargar los datos al llamar al findAll() del dao
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}
	
	@Test
	void testCrearPelicula() {
		// Patron AAA  ->  JUnit (TDD)
		// Patron Given, When, Then  -> Mockito (BDD)
		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		//Mockito.when(dao.crear(peliculaNueva)).thenReturn(Datos.PELICULA);
		// Ahora mockeamos la pelicula a crear
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		// Con verify comprobamos que se invoco al metodo crear del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class));
	}
	
	@Test
	void testCrearPeliculaConActores() {		
		// 1.- Given
		Pelicula peliculaNueva = Datos.PELICULA;
		peliculaNueva.setActores(Datos.ACTORES);

		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).thenReturn(Datos.PELICULA);
		
		// 2.- When
		Pelicula pelicula = bs.crear(peliculaNueva);
		
		// 3.- Then
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(4L, pelicula.getId());
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
		
		// Con verify comprobamos que se invoco al metodo crear del mock dao
		Mockito.verify(dao).crear(Mockito.any(Pelicula.class)); // crear un mock de Pelicula
		Mockito.verify(actoresDAO).crearListaActores(Mockito.anyList()); // crear un mock de List
	}
	
	@Test
	void testActoresPeliculaVerifiy() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("Infiltrada");
		
		Assertions.assertEquals("La Infiltrada", pelicula.getNombre());
		
		// Con verify estos son los metodos de los mock que estamos llamando
		Mockito.verify(dao).findAll();
		Mockito.verify(actoresDAO).findActoresByPeliculaId(2L);
		
		// Pero este metodo no es invocado
		// Mockito.verify(actoresDAO).crearListaActores(Datos.ACTORES);
	}
	
	@Test
	void testExcepciones() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong()))
			.thenThrow(RuntimeException.class);
		
		Exception ex = Assertions.assertThrows(RuntimeException.class, () -> {
			bs.findPeliculaByNombreConActores("habitacion");
		});
		
		Assertions.assertEquals(RuntimeException.class, ex.getClass());
	}
	
	@Test
	void testArgumentMatchers() {
		// Con ArgumentMatchers validar que argumentos estamos pasando en las llamadas del mock
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		bs.findPeliculaByNombreConActores("habitacion");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.argThat(arg -> arg != null && arg.equals(3L)));
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.eq(3L));
	}
	
	// Crear un ArgumentMatcher personalizado
	public static class MiArgumentMatcher implements ArgumentMatcher<Long>{
		
		private Long argument;

		@Override
		public boolean matches(Long argument) {
			this.argument = argument;
			return argument != null && argument > 0;
		}
		
		@Override
		public String toString() {
			return "ERROR: " + argument + " debe ser un numero positivo";
		}		
	}
	
	@Test
	void testMiArgumentMatcher() {
		// Con ArgumentMatchers validar que argumentos estamos pasando en las llamadas del mock
		// Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS_ID_NEGATIVO); La prueba falla
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);   // la prueba pasa
		Mockito.when(actoresDAO.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		bs.findPeliculaByNombreConActores("47");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(ArgumentMatchers.argThat(new MiArgumentMatcher()));
	}
	
	@Test
	void testCapturarArgumentos() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		bs.findPeliculaByNombreConActores("habitacion");
		
		// Crear una instancia de ArgumentCaptor para capturar los argumentos
		// Esto se puede hacer de 2 formas: programatica o @Captor		
		// ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(captor.capture());
		Assertions.assertEquals(3L, captor.getValue());
	}
	
	@Test
	void testDoThrow() {
		Pelicula pelicula = Datos.PELICULA;
		pelicula.setActores(Datos.ACTORES);
		
		// No podemos utilizar when cuando el metodo es de tipo void
		//Mockito.when(actoresDAO.crearListaActores(null)).thenThrow(RuntimeExcepcion.class);
		
		// La alternativa es doThrow
		Mockito.doThrow(RuntimeException.class).when(actoresDAO).crearListaActores(Mockito.anyList());
		
		Assertions.assertThrows(RuntimeException.class, () -> {
			bs.crear(pelicula);
		});
	}
	
	@Test
	void testCallRealMethod() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		// Vamos a forzar para que el mock llame al metodo real
		Mockito.doCallRealMethod().when(actoresDAO).findActoresByPeliculaId(Mockito.anyLong());
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("habitacion");
		
		Assertions.assertEquals(3L, pelicula.getId());
		Assertions.assertTrue(pelicula.getActores().size() == 3);
	}
	
	// Spy es un hibrido entre los mock y los objetos reales
	// Spy al igual que doCallRealMethod no funciona con interfaces o clases abstractas
	@Test
	void testSpy() {
		PeliculasDAOImpl peliculasSpy = Mockito.spy(PeliculasDAOImpl.class);
		ActoresDAOImpl actoresSpy = Mockito.spy(ActoresDAOImpl.class);
		IPeliculasBS peliculasBS = new PeliculasBSImpl(peliculasSpy, actoresSpy);
		
		// Con spy puedo llamar al metodo real
		// Mockito.when(actoresSpy.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Con spy puedo llamar al metodo ficticio
		Mockito.doReturn(Datos.PELICULAS).when(peliculasSpy).findAll();
		Mockito.doReturn(Datos.ACTORES).when(actoresSpy).findActoresByPeliculaId(Mockito.anyLong());
		
		Pelicula pelicula = peliculasBS.findPeliculaByNombreConActores("Infiltrada");
		
		Assertions.assertEquals(2L, pelicula.getId());
		Assertions.assertEquals("La Infiltrada", pelicula.getNombre());
		Assertions.assertTrue(pelicula.getActores().size() == 3);
	}
	
	@Test
	void testOrdenEnMocks() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		bs.findPeliculaByNombreConActores("47");
		bs.findPeliculaByNombreConActores("Infiltrada");
				
		InOrder order = Mockito.inOrder(actoresDAO, dao); // Aqui el orden de los mock da igual
		order.verify(dao).findAll();
		order.verify(actoresDAO).findActoresByPeliculaId(1L);
		
		order.verify(dao).findAll();
		order.verify(actoresDAO).findActoresByPeliculaId(2L);		
	}
	
	@Test
	void testNumeroInvocaciones() {
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		bs.findPeliculaByNombreConActores("Infiltrada");
		
		Mockito.verify(actoresDAO).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.times(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atLeast(1)).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atLeastOnce()).findActoresByPeliculaId(2L);
		Mockito.verify(actoresDAO, Mockito.atMost(1)).findActoresByPeliculaId(2L);
	}
	
	@Test
	void testCrearPeliculaIdIncremental() {
		Pelicula pelicula = Datos.PELICULA_NULL;
		pelicula.setActores(Datos.ACTORES);
		
		Mockito.when(dao.crear(Mockito.any(Pelicula.class))).then(new Answer<Pelicula>() {
			
			Long secuencia = 3L;

			@Override
			public Pelicula answer(InvocationOnMock invocation) throws Throwable {
				Pelicula pelicula = invocation.getArgument(0);  // coger la pelicula que vamos a crear
				// Lanzar findAll() para ver cual es el ultimo id
				pelicula.setId(++secuencia);
				return pelicula;
			}
		});
		
		Pelicula peliculaNueva = bs.crear(pelicula);
		
		Assertions.assertEquals(4L, peliculaNueva.getId());		
	}
	
	@Test
	void testDoAnswerCrearPelicula() {
		Pelicula pelicula = Datos.PELICULA_NULL;
		pelicula.setActores(Datos.ACTORES);
		
		Mockito.doAnswer(new Answer<Pelicula>() {
			
			Long secuencia = 3L;

			@Override
			public Pelicula answer(InvocationOnMock invocation) throws Throwable {
				Pelicula pelicula = invocation.getArgument(0);  // coger la pelicula que vamos a crear
				// Lanzar findAll() para ver cual es el ultimo id
				pelicula.setId(++secuencia);
				return pelicula;
			}
		}).when(dao).crear(Mockito.any(Pelicula.class));
		
		Pelicula peliculaNueva = bs.crear(pelicula);
		
		Assertions.assertEquals(4L, peliculaNueva.getId());		
	}
	
}

















