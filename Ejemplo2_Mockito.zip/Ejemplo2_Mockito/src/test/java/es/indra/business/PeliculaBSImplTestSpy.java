package es.indra.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import es.indra.models.Pelicula;
import es.indra.persistence.ActoresDAOImpl;
import es.indra.persistence.PeliculasDAOImpl;
import es.indra.utils.Datos;

@ExtendWith(MockitoExtension.class)
public class PeliculaBSImplTestSpy {
	
	@Spy
	PeliculasDAOImpl peliculasSpy;
	
	@Spy
	ActoresDAOImpl actoresSpy;
	
	@InjectMocks
	// No puedo inyectar dependencias en una interface, es necesario utilizar la clase
	PeliculasBSImpl peliculasBS;

	// Spy es un hibrido entre los mock y los objetos reales
	// Spy al igual que doCallRealMethod no funciona con interfaces o clases
	// abstractas
	@Test
	void testSpy() {
		// Con spy puedo llamar al metodo real
		Mockito.when(actoresSpy.findActoresByPeliculaId(Mockito.anyLong())).thenReturn(Datos.ACTORES);

		// Con spy puedo llamar al metodo ficticio
		//Mockito.doReturn(Datos.PELICULAS).when(peliculasSpy).findAll();
		//Mockito.doReturn(Datos.ACTORES).when(actoresSpy).findActoresByPeliculaId(Mockito.anyLong());

		Pelicula pelicula = peliculasBS.findPeliculaByNombreConActores("Infiltrada");

		Assertions.assertEquals(2L, pelicula.getId());
		Assertions.assertEquals("La Infiltrada", pelicula.getNombre());
		Assertions.assertTrue(pelicula.getActores().size() == 3);
	}

}
