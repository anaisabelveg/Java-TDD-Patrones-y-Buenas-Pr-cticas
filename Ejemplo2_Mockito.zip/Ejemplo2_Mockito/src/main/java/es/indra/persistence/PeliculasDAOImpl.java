package es.indra.persistence;

import java.util.Arrays;
import java.util.List;

import es.indra.models.Pelicula;

public class PeliculasDAOImpl implements IPeliculasDAO{

	@Override
	public List<Pelicula> findAll() {
		System.out.println("Metodo findAll() de PeliculasDAOImpl");
		return Arrays.asList(new Pelicula(1L, "El 47"),
				new Pelicula(2L, "La Infiltrada"),
				new Pelicula(3L, "La habitacion de al lado"));
	}

	@Override
	public Pelicula crear(Pelicula pelicula) {
		System.out.println("Metodo crear() de PeliculasDAOImpl");
		return pelicula;
	}

}
