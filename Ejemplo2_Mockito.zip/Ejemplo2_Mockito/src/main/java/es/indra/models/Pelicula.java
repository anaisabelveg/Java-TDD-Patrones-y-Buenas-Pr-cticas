package es.indra.models;

public class Pelicula {

	private Long id;
	private String nombre;

	public Pelicula() {
		// TODO Auto-generated constructor stub
	}

	public Pelicula(Long id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Pelicula [id=" + id + ", nombre=" + nombre + "]";
	}

}
