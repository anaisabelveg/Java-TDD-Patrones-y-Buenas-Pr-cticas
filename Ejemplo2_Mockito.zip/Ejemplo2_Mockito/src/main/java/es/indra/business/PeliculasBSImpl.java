package es.indra.business;

import java.util.Optional;

import es.indra.models.Pelicula;
import es.indra.persistence.IPeliculasDAO;

public class PeliculasBSImpl implements IPeliculasBS {

	private IPeliculasDAO dao;

	public PeliculasBSImpl(IPeliculasDAO dao) {
		super();
		this.dao = dao;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliOptional = dao.findAll()
			.stream()
			.filter(peli -> peli.getNombre().contains(nombre))
			.findFirst();
		
		Pelicula pelicula = null;
		if (peliOptional.isPresent()) {
			pelicula = peliOptional.get();
		}
		return pelicula;
	}

	@Override
	public Pelicula crear(Pelicula pelicula) {
		return dao.crear(pelicula);
	}

}
