package es.indra.business;

import java.util.List;
import java.util.Optional;

import es.indra.models.Pelicula;
import es.indra.persistence.IActoresDAO;
import es.indra.persistence.IPeliculasDAO;

public class PeliculasBSImpl implements IPeliculasBS {

	private IPeliculasDAO peliculasDAO;
	private IActoresDAO actoresDAO;

	public PeliculasBSImpl(IPeliculasDAO peliculasDAO, IActoresDAO actoresDAO) {
		super();
		this.peliculasDAO = peliculasDAO;
		this.actoresDAO = actoresDAO;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliOptional = peliculasDAO.findAll().stream()
				.filter(peli -> peli.getNombre().contains(nombre)).findFirst();

		Pelicula pelicula = null;
		if (peliOptional.isPresent()) {
			pelicula = peliOptional.get();
		}
		return pelicula;
	}

	@Override
	public Pelicula findPeliculaByNombreConActores(String nombre) {
		Pelicula pelicula = findPeliculaByNombre(nombre);
		
		if (pelicula != null) {
			List<String> reparto = actoresDAO.findActoresByPeliculaId(pelicula.getId());
			pelicula.setActores(reparto);
		}
		return pelicula;
	}

	@Override
	public Pelicula crear(Pelicula pelicula) {
		if (!pelicula.getActores().isEmpty()) {
			actoresDAO.crearListaActores(pelicula.getActores());
		}
		return peliculasDAO.crear(pelicula);
	}

}
